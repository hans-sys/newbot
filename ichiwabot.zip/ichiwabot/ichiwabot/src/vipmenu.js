const vipmenu = (prefix) => { 
	return `            
	
╔══✪〘 VIP USER 〙✪══
║
╰─⊱ *${prefix}ytmp4 [link]*
╰─⊱ *${prefix}ytmp3 [link]*
╰─⊱ *${prefix}hidetag2*
╰─⊱ *${prefix}joox [lagu]*
╰─⊱ *${prefix}tomp3 [replay video]*
╰─⊱  *${prefix}otagall2*
╰─⊱  *${prefix}otagall3*
╰─⊱  *${prefix}hidetag5*
╰─⊱  *${prefix}indo(1-25)*
╰─⊱  *CONTOH ${prefix}indo1*
║
╚══✪〘  HANS BOT 〙✪══
`
}
exports.vipmenu = vipmenu